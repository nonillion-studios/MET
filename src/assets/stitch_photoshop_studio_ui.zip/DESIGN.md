---
name: Obsidian Edit
colors:
  surface: '#121414'
  surface-dim: '#121414'
  surface-bright: '#37393a'
  surface-container-lowest: '#0c0f0f'
  surface-container-low: '#1a1c1c'
  surface-container: '#1e2020'
  surface-container-high: '#282a2b'
  surface-container-highest: '#333535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#c4c7c7'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#2f3131'
  outline: '#8e9192'
  outline-variant: '#444748'
  surface-tint: '#c8c6c5'
  primary: '#c8c6c5'
  on-primary: '#303030'
  primary-container: '#1e1e1e'
  on-primary-container: '#878585'
  inverse-primary: '#5f5e5e'
  secondary: '#98cbff'
  on-secondary: '#003354'
  secondary-container: '#00a2fd'
  on-secondary-container: '#003558'
  tertiary: '#c8c6c6'
  on-tertiary: '#303030'
  tertiary-container: '#1e1e1e'
  on-tertiary-container: '#878585'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1b1b1c'
  on-primary-fixed-variant: '#474746'
  secondary-fixed: '#cfe5ff'
  secondary-fixed-dim: '#98cbff'
  on-secondary-fixed: '#001d33'
  on-secondary-fixed-variant: '#004a77'
  tertiary-fixed: '#e4e2e1'
  tertiary-fixed-dim: '#c8c6c6'
  on-tertiary-fixed: '#1b1c1c'
  on-tertiary-fixed-variant: '#474747'
  background: '#121414'
  on-background: '#e2e2e2'
  surface-variant: '#333535'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
  mono-label:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 12px
  margin-mobile: 16px
  toolbar-height: 56px
  bottom-sheet-margin: 8px
---

## Brand & Style

The design system is engineered for a professional, high-utility mobile photo editing environment. The brand personality is precise, unobtrusive, and authoritative, ensuring the user's content remains the focal point. 

The style utilizes a **Minimalist Corporate** approach with a "Darkroom" aesthetic. It prioritizes functionality over decoration, using a strictly dark interface to minimize eye strain and maximize color perception. Visual hierarchy is established through subtle tonal shifts rather than vibrant colors, creating a focused workspace that mirrors high-end desktop creative suites. The target audience includes professional photographers and digital artists who require a reliable, systematic toolset on the move.

## Colors

The palette is optimized for professional image manipulation. 
- **Primary (#1E1E1E):** The foundational canvas color. It provides a deep, neutral backdrop that does not interfere with the color accuracy of the photo being edited.
- **Secondary / Accent (#00A3FF):** Used sparingly for active states, selection indicators, and primary action buttons. It provides high contrast against the dark background for immediate recognition.
- **Tertiary (#2D2D2D):** Utilized for elevated surfaces, such as toolbars, panels, and floating menus, to provide a subtle sense of depth.
- **Neutral (#FFFFFF):** Reserved for high-priority text and iconography. Low-priority labels should use a reduced opacity (e.g., 60%) rather than a different hex code to maintain a clean gray scale.

## Typography

The typography system uses **Inter** for its exceptional legibility at small sizes and high information density. 

- **Headlines:** Used primarily for screen titles or modal headers. They should be tight and impactful.
- **Body:** Used for general descriptions and settings.
- **Labels:** Crucial for the tool-heavy interface. `label-sm` is used for toolbar icons and technical metadata, while `label-md` handles standard UI controls.
- **Mono-label:** A secondary font (JetBrains Mono) is introduced specifically for numeric values (e.g., ISO, shutter speed, or RGB coordinates) to prevent layout jumping during adjustments.

## Layout & Spacing

This design system uses a **4px baseline grid** to ensure precise alignment of complex toolsets. 

- **The Main Canvas:** A fluid area that maximizes the photo view.
- **Toolbars:** Fixed at the bottom for ergonomic thumb access. Icons are spaced consistently with 12px gutters.
- **Panels:** Side-drawers or bottom-sheets used for granular adjustments (like curves or layers) use a 16px internal margin.
- **Responsive Behavior:** On larger mobile devices or tablets, the toolbars transition from bottom-docked to side-pinned (left or right) to maintain maximum vertical workspace for the image.

## Elevation & Depth

In this dark-themed professional environment, elevation is communicated through **Tonal Layering** and **Low-Contrast Outlines**.

1.  **Level 0 (Base):** Deep Charcoal (#1E1E1E) for the main application background.
2.  **Level 1 (Surface):** Lighter Charcoal (#252525) for toolbars and inactive panels.
3.  **Level 2 (Active):** Soft Gray (#2D2D2D) for modals and active tool settings.

Shadows are used sparingly. When used for floating action buttons or menus, they are tight, non-diffused, and purely black to simulate a physical stack without creating visual "fuzziness" that could distract from image sharpness. Subtle 1px borders (#333333) are used to define boundaries between tool areas and the canvas.

## Shapes

The shape language is **Soft (0.25rem)**. 

While the overall vibe is professional and rigid, the slight rounding of corners prevents the UI from feeling aggressive. 
- **Buttons and Inputs:** 4px radius (Soft).
- **Cards and Panels:** 8px radius (rounded-lg).
- **Active Indicators:** Small circles or rounded pills for toggle states.
- **Icon Enclosures:** When icons are contained, they should use a square-with-radius shape rather than a full circle to maintain the architectural feel of the interface.

## Components

- **Buttons:** 
  - *Primary:* Filled with Adobe Blue (#00A3FF), white text.
  - *Secondary:* Ghost style with #333333 border and white text.
  - *Tool-item:* No background; turns Blue (#00A3FF) and adds a small 2px blue dot underneath when active.
- **Sliders:** High-precision controls. The track is #333333, and the active portion is Blue. The "thumb" should be a 16px white circle for tactile feedback.
- **Chips:** Used for filter names or metadata tags. Small 4px radius, #2D2D2D background, and #FFFFFF text (80% opacity).
- **Input Fields:** Darker than the background (#181818) with a 1px border. Focus state changes the border to Adobe Blue.
- **Layers List:** Vertical list with 48px height per item. Each item shows a thumbnail, visibility toggle (eye icon), and lock status. Active layers have a subtle #2D2D2D background highlight.
- **Bottom Sheets:** Used for "Advanced Settings." They should feature a drag handle at the top and a semi-transparent #1E1E1E background with a Backdrop Blur (20px) to maintain context.